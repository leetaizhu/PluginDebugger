print "hi"

print "Like bad Windows newlines?"
